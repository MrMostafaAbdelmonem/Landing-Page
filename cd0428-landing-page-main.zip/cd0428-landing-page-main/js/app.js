/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/



/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/

let list= document.getElementById('navbar__lists');
let sections =document.querySelectorAll('section');

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
sections.forEach((section) => {
 let li = document.createElement("li");
 sectionName = section.getAttribute("data-nav");
 li.innerHTML=`<a class="menu__link"href="#${section.id}">${sectionName}</a>`
 list.appendChild(li);
    function activList(){
 if(section.getBoundingClientRect().top >= -400 && section.getBoundingClientRect().top <= 200){
  li.classList.add('link-active');
 }else{
  li.classList.remove('link-active');
}
 }
 document.addEventListener('scroll',activList);
});

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav


// Add class 'active' to section when near top of viewport
function activeClass(){
  for(section of sections){
    
    if(section.getBoundingClientRect().top >= -400 && section.getBoundingClientRect().top <= 200){
      section.classList.add('your-active-class');

    }else{
      section.classList.remove('your-active-class');      
    }
  }

}
document.addEventListener('scroll',activeClass)


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


